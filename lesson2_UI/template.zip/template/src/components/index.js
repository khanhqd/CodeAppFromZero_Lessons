export { default as CloneMeComponent } from './_CloneMe';
