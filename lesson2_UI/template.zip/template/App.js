
import React from 'react';
import Navigation from './src/navigation/Navigation';

function App() {
  return (
    <Navigation />
  );
}

export default App;